// ============================================================
// ClearSpend — purchase.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   6. PURCHASE SCREEN
   ================================================================ */

// Redraws the full purchase history list (newest first).
function renderPurchases() {
  const el = document.getElementById('p-list');
  if (state.purchases.length === 0) {
    el.innerHTML = '<p class="empty-state">No purchases yet. Add a card first, then log a purchase.</p>';
    return;
  }
  el.innerHTML = state.purchases.slice().reverse().map(p => `
    <div class="list-row">
      <div style="display:flex;align-items:center;gap:10px">
        ${getNetTag(p.cardType)}
        <div>
          <div class="list-row-main">${fmt(p.amt)}</div>
          <div class="list-row-sub">${p.cardName}${p.note ? ' · ' + p.note : ''} · ${p.cat}</div>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:12px;color:var(--text3)">${p.date}</span>
        <button class="btn-danger" onclick="removePurchase(${p.id})">×</button>
      </div>
    </div>`).join('');
}

// Records a new purchase: validates input, attaches card info, saves, re-renders.
function logPurchase() {
  const amt = parseFloat(document.getElementById('p-amt').value) || 0;
  const cardId = parseInt(document.getElementById('p-card').value) || 0;

  if (!amt || !cardId) {
    alert('Please enter an amount and select a card.');
    return;
  }

  const card = state.cards.find(c => c.id === cardId);
  if (!card) return; // shouldn't happen, but guard just in case

  // Default to today's date if none was picked
  const dateVal = document.getElementById('p-date').value || new Date().toISOString().split('T')[0];

  state.purchases.push({
    amt,
    cardId,
    cardName: card.name,     // we copy the name/type at the time of purchase
    cardType: card.type,     // so the record still makes sense if the card is later deleted
    cat: document.getElementById('p-cat').value,
    note: document.getElementById('p-note').value.trim(),
    date: dateVal,
    id: Date.now()
  });

  // Clear just the amount and note (keep card/category/date for quick repeat entries)
  document.getElementById('p-amt').value = '';
  document.getElementById('p-note').value = '';

  saveState();
  renderPurchases();
  renderHome();     // available balance changed
  renderCards();    // card utilization changed
  renderCalendar(); // today's spending changed
}

// Deletes a purchase by id and refreshes every screen that depends on purchase data.
function removePurchase(id) {
  state.purchases = state.purchases.filter(p => p.id !== id);
  saveState();
  renderPurchases();
  renderHome();
  renderCards();
  renderCalendar();
}

// Refreshes the "Card used" dropdown on the Purchase screen so it always
// lists the cards currently in `state.cards`.
function updateCardDropdown() {
  const sel = document.getElementById('p-card');
  sel.innerHTML = '<option value="">— Select card —</option>' +
    state.cards.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
}

// ============================================================
// ClearSpend — app.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   4. NAVIGATION
   ----------------------------------------------------------------
   Handles clicking the top-bar tabs: hides all screens, shows the
   one that was clicked, and highlights the active tab button.
   Also triggers a re-render of that screen's data so it's always
   up to date when you switch to it.
   ================================================================ */
function setupNav() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const section = btn.dataset.section; // e.g. "calendar"

      // Remove "active" from all tabs and all screens...
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));

      // ...then add it back to just the clicked tab and matching screen.
      btn.classList.add('active');
      document.getElementById('s-' + section).classList.add('active');

      // Some screens need fresh data every time they're opened:
      if (section === 'calendar') renderCalendar();
      if (section === 'review')   renderYearReview();
      if (section === 'purchase') updateCardDropdown();
    });
  });
}


/* ================================================================
   12. INIT — runs once when the page finishes loading
   ================================================================ */

// Re-renders every screen. Called on load and after major data changes
// where multiple screens could be affected.
function renderAll() {
  renderHome();
  renderPurchases();
  renderCards();
  renderGoals();
  renderCalendar();
  updateCardDropdown();
}

document.addEventListener('DOMContentLoaded', () => {
  loadState();                                              // 1. load saved data (if any)
  document.getElementById('p-date').value = new Date().toISOString().split('T')[0]; // 2. default purchase date = today
  populateYearDropdown();                                   // 3. fill the year picker on Year Review
  setupNav();                                               // 4. wire up the top nav buttons
  restoreIncomeForm();                                      // 5. re-fill the income form from saved state
  renderAll();                                              // 6. draw everything
});

// ============================================================
// ClearSpend — home.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   5. HOME SCREEN
   ================================================================ */

// Redraws everything on the Home/Overview screen using current `state`.
function renderHome() {
  const now = new Date();
  const month = now.getMonth();
  const year = now.getFullYear();

  const fixedTotal = state.expenses.reduce((s, e) => s + e.amt, 0);
  const monthPurchases = getMonthPurchases(year, month);
  const purchTotal = monthPurchases.reduce((s, p) => s + p.amt, 0);

  const monthlyIncome = getMonthlyIncome(year, month);
  const avail = monthlyIncome - fixedTotal - purchTotal;

  const days = new Date(year, month + 1, 0).getDate();
  const daily = monthlyIncome > 0 ? (monthlyIncome - fixedTotal) / days : 0;

  // ---- Top stat tiles ----
  document.getElementById('h-avail').textContent = fmt(avail);
  document.getElementById('h-avail').className = 'stat-val ' + (avail >= 0 ? 'green' : 'red');
  document.getElementById('h-spent').textContent = fmt(purchTotal);
  document.getElementById('h-daily').textContent = fmt(daily);
  document.getElementById('h-fixed').textContent = fmt(fixedTotal);
  document.getElementById('home-sub').textContent = now.toLocaleString('default', { month: 'long', year: 'numeric' });

  // ---- Small explanation under "Available balance" for non-monthly pay ----
  // This tells the user HOW their monthly income was calculated, e.g.
  // "$3,000.00 this month (2 paychecks × $1,500.00)"
  const incomeSubEl = document.getElementById('h-income-sub');
  if (incomeSubEl) {
    if (state.incomeFreq === 'monthly' || state.income === 0) {
      incomeSubEl.textContent = '';
    } else {
      const payDates = getPayDatesInMonth(year, month);
      const count = state.payMode === 'average'
        ? Math.round(state.incomeFreq === 'weekly' ? 4.33 : 2.17)
        : payDates.length;
      incomeSubEl.textContent = `${fmt(monthlyIncome)} this month (${count} paycheck${count === 1 ? '' : 's'} × ${fmt(state.income)})`;
    }
  }

  // ---- Fixed expenses list ----
  const el = document.getElementById('exp-list');
  el.innerHTML = state.expenses.length === 0
    ? '<p class="empty-state">No fixed payments yet</p>'
    : state.expenses.map(e => `
        <div class="list-row">
          <div class="list-row-main">${e.name}</div>
          <div style="display:flex;align-items:center;gap:12px">
            <span style="font-size:14px;font-weight:700">${fmt(e.amt)}</span>
            <button class="btn-danger" onclick="removeExpense(${e.id})">×</button>
          </div>
        </div>`).join('');

  // ---- Spending breakdown progress bars ----
  if (monthlyIncome > 0) {
    const fp = Math.min(100, fixedTotal / monthlyIncome * 100);   // % spent on fixed bills
    const pp = Math.min(100, purchTotal / monthlyIncome * 100);   // % spent on purchases
    const rp = Math.max(0, 100 - fp - pp);                        // % remaining
    document.getElementById('pb-fixed').style.width = fp + '%';
    document.getElementById('pb-purch').style.width = pp + '%';
    document.getElementById('pb-remain').style.width = rp + '%';
    document.getElementById('b-fixed').textContent = fmt(fixedTotal) + ' (' + Math.round(fp) + '%)';
    document.getElementById('b-purch').textContent = fmt(purchTotal) + ' (' + Math.round(pp) + '%)';
    document.getElementById('b-remain').textContent = fmt(Math.max(0, avail)) + ' (' + Math.round(rp) + '%)';
  } else {
    // No income set yet — show placeholders instead of 0%/NaN
    ['b-fixed','b-purch','b-remain'].forEach(id => document.getElementById(id).textContent = '—');
    ['pb-fixed','pb-purch','pb-remain'].forEach(id => document.getElementById(id).style.width = '0%');
  }

  // ---- Recent activity (last 5 purchases, most recent first) ----
  const recent = document.getElementById('recent-activity');
  if (state.purchases.length === 0) {
    recent.innerHTML = '<p class="empty-state">No purchases yet</p>';
  } else {
    recent.innerHTML = state.purchases.slice().reverse().slice(0, 5).map(p => `
      <div class="list-row">
        <div style="display:flex;align-items:center;gap:10px">
          ${getNetTag(p.cardType)}
          <div>
            <div class="list-row-main">${fmt(p.amt)}</div>
            <div class="list-row-sub">${p.cardName}${p.note ? ' · ' + p.note : ''}</div>
          </div>
        </div>
        <span style="font-size:12px;color:var(--text3)">${p.date}</span>
      </div>`).join('');
  }
}

// Called when the user changes the income Frequency dropdown.
// Shows/hides the pay-schedule section and tweaks the "Amount" label.
function onIncomeFreqChange() {
  const freq = document.getElementById('inc-freq').value;
  const scheduleSection = document.getElementById('pay-schedule-section');

  if (freq === 'monthly') {
    scheduleSection.style.display = 'none';
    document.getElementById('inc-amt-label').textContent = 'Amount ($)';
  } else {
    scheduleSection.style.display = 'block';
    document.getElementById('inc-amt-label').textContent = 'Amount per paycheck ($)';
  }
}

// Called when the user picks a pay-mode radio button (average/pattern/manual).
// Highlights the selected option and shows the matching extra input box.
function onPayModeChange(mode) {
  state.payMode = mode;

  // Highlight the selected radio "card"
  document.querySelectorAll('.radio-option[data-pay-mode]').forEach(el => {
    el.classList.toggle('selected', el.dataset.payMode === mode);
  });

  // Show only the relevant extra box
  document.getElementById('pay-pattern-box').classList.toggle('show', mode === 'pattern');
  document.getElementById('pay-manual-box').classList.toggle('show', mode === 'manual');

  renderManualDateTags();
}

// Adds the date currently in the "pay-manual-date" input to the list
// of manual pay dates (avoiding duplicates), then clears the input.
function addManualPayDate() {
  const val = document.getElementById('pay-manual-date').value;
  if (!val) return;
  if (!state.payManualDates.includes(val)) {
    state.payManualDates.push(val);
    state.payManualDates.sort(); // keep them in chronological order
  }
  document.getElementById('pay-manual-date').value = '';
  renderManualDateTags();
}

// Removes one date from the manual pay dates list (called by the × on each chip).
function removeManualPayDate(dateStr) {
  state.payManualDates = state.payManualDates.filter(d => d !== dateStr);
  renderManualDateTags();
}

// Redraws the small "chips" showing each manually-added pay date.
function renderManualDateTags() {
  const el = document.getElementById('manual-date-tags');
  if (!el) return;
  if (state.payManualDates.length === 0) {
    el.innerHTML = '<p class="empty-state" style="padding:10px">No pay dates added yet</p>';
    return;
  }
  el.innerHTML = state.payManualDates.map(d => `
    <span class="date-tag">${d}<button onclick="removeManualPayDate('${d}')">×</button></span>
  `).join('');
}

// Saves everything from the "Set your income" card into `state`.
function saveIncome() {
  const amt = parseFloat(document.getElementById('inc-amt').value) || 0;
  const freq = document.getElementById('inc-freq').value;
  state.income = amt;
  state.incomeFreq = freq;

  if (freq !== 'monthly') {
    // Read whichever pay-mode radio is currently checked
    const selectedMode = document.querySelector('input[name="pay-mode"]:checked');
    state.payMode = selectedMode ? selectedMode.value : 'average';

    if (state.payMode === 'pattern') {
      state.payAnchorDate = document.getElementById('pay-anchor-date').value || '';
    }
  } else {
    state.payMode = 'average'; // not really used for monthly, but keep it consistent
  }

  saveState();
  renderHome();
  renderCalendar();
}

// Adds a new fixed monthly expense (rent, subscriptions, etc.)
function addExpense() {
  const name = document.getElementById('exp-n').value.trim();
  const amt = parseFloat(document.getElementById('exp-a').value) || 0;
  if (!name || !amt) return; // ignore empty/invalid entries

  state.expenses.push({ name, amt, id: Date.now() }); // Date.now() = unique-enough id
  document.getElementById('exp-n').value = '';
  document.getElementById('exp-a').value = '';

  saveState();
  renderHome();
  renderCalendar(); // daily budget depends on fixed expenses, so refresh calendar too
}

// Removes a fixed expense by its id.
function removeExpense(id) {
  state.expenses = state.expenses.filter(e => e.id !== id);
  saveState();
  renderHome();
  renderCalendar();
}

// On page load, re-fill the income form with whatever was saved,
// and restore the pay-mode radio selection / manual date chips.
function restoreIncomeForm() {
  if (state.income > 0) document.getElementById('inc-amt').value = state.income;
  document.getElementById('inc-freq').value = state.incomeFreq || 'monthly';
  onIncomeFreqChange();

  const mode = state.payMode || 'average';
  const radio = document.querySelector(`input[name="pay-mode"][value="${mode}"]`);
  if (radio) radio.checked = true;
  onPayModeChange(mode);

  if (state.payAnchorDate) document.getElementById('pay-anchor-date').value = state.payAnchorDate;
  renderManualDateTags();
}

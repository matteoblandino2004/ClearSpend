// ============================================================
// ClearSpend — review.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   11. YEAR REVIEW SCREEN
   ================================================================ */

// Builds the full year-in-review: green/red day counts, a per-month
// heatmap of dots (one per day), and a spending-by-category breakdown.
function renderYearReview() {
  const year = parseInt(document.getElementById('review-year').value) || new Date().getFullYear();
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];

  let totalGreen = 0, totalRed = 0, totalSpent = 0;
  let monthsHtml = '';
  const catTotals = {}; // running total of $ spent per category, across the whole year

  months.forEach((mn, mi) => {
    const days = new Date(year, mi + 1, 0).getDate();
    const daily = getDailyBudget(year, mi);
    let greenD = 0, redD = 0;

    // Build one little colored square (dot) per day of this month
    const dots = Array.from({ length: days }, (_, i) => {
      const d = i + 1;
      const dateStr = `${year}-${String(mi + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const dayPurchases = getDayPurchases(dateStr);
      const spent = dayPurchases.reduce((s, p) => s + p.amt, 0);

      // Tally category totals while we're already looping through every purchase
      dayPurchases.forEach(p => { catTotals[p.cat] = (catTotals[p.cat] || 0) + p.amt; });

      totalSpent += spent;

      if (spent === 0) return '<div class="yr-dot none" title="No spending"></div>';
      if (daily > 0 && spent > daily) {
        redD++; totalRed++;
        return `<div class="yr-dot red" title="${dateStr}: ${fmt(spent)} — over budget"></div>`;
      }
      greenD++; totalGreen++;
      return `<div class="yr-dot green" title="${dateStr}: ${fmt(spent)} — on track"></div>`;
    }).join('');

    const score = greenD + redD > 0 ? Math.round(greenD / (greenD + redD) * 100) : null;

    monthsHtml += `
      <div class="yr-month-block">
        <div class="yr-month-label"><span>${mn}</span>
          <span style="font-size:12px;color:var(--text3)">
            ${greenD > 0 ? `<span style="color:var(--green)">${greenD} ✓</span> ` : ''}
            ${redD > 0 ? `<span style="color:var(--red)">${redD} ✗</span>` : ''}
            ${score !== null ? ` · ${score}%` : ''}
          </span>
        </div>
        <div class="yr-dots">${dots}</div>
      </div>`;
  });

  // ---- Top summary tiles ----
  const score = totalGreen + totalRed > 0 ? Math.round(totalGreen / (totalGreen + totalRed) * 100) : 0;
  document.getElementById('yr-stats').innerHTML = `
    <div class="stat-card"><div class="stat-label">Green days</div><div class="stat-val green">${totalGreen}</div></div>
    <div class="stat-card"><div class="stat-label">Red days</div><div class="stat-val red">${totalRed}</div></div>
    <div class="stat-card"><div class="stat-label">Total spent</div><div class="stat-val">${fmt(totalSpent)}</div></div>
    <div class="stat-card"><div class="stat-label">Budget score</div><div class="stat-val orange">${score}%</div></div>`;
  document.getElementById('yr-heatmap').innerHTML = monthsHtml;

  // ---- Category breakdown bars, sorted highest spending first ----
  const catLabels = { food:'Food & dining', gas:'Transport', shopping:'Shopping', entertainment:'Entertainment', health:'Health', utilities:'Utilities', travel:'Travel', other:'Other' };
  const sorted = Object.entries(catTotals).sort((a, b) => b[1] - a[1]);
  const maxCat = sorted.length > 0 ? sorted[0][1] : 1; // avoid divide-by-zero
  document.getElementById('yr-categories').innerHTML = sorted.length === 0
    ? '<p class="empty-state">No spending data yet</p>'
    : sorted.map(([cat, amt]) => `
        <div style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--text2);margin-bottom:4px"><span>${catLabels[cat] || cat}</span><span style="color:var(--text)">${fmt(amt)}</span></div>
          <div class="prog-bar"><div class="prog-fill blue" style="width:${(amt / maxCat * 100).toFixed(1)}%"></div></div>
        </div>`).join('');
}

// Fills the year dropdown with the current year and the two previous years.
function populateYearDropdown() {
  const sel = document.getElementById('review-year');
  const thisYear = new Date().getFullYear();
  sel.innerHTML = [thisYear, thisYear - 1, thisYear - 2]
    .map(y => `<option value="${y}" ${y === thisYear ? 'selected' : ''}>${y}</option>`)
    .join('');
}

// ============================================================
// ClearSpend — calculator.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   10. CALCULATOR SCREEN  (redesigned)
   ----------------------------------------------------------------
   Inputs:
     cc-limit   = total credit limit on the card
     cc-charged = how much of that limit has been used/charged
     cc-apr     = annual percentage rate (interest rate)
     cc-due     = the actual due date (a calendar date, not "days from now")
     cc-pay     = OPTIONAL planned monthly payment

   The function below recalculates everything live as the user types
   (it's wired to oninput on each field).
   ================================================================ */
function runCalc() {
  const limit   = parseFloat(document.getElementById('cc-limit').value)   || 0;
  const charged = parseFloat(document.getElementById('cc-charged').value) || 0;
  const apr     = parseFloat(document.getElementById('cc-apr').value)     || 0;
  const dueStr  = document.getElementById('cc-due').value; // "YYYY-MM-DD" or ""
  const pay     = parseFloat(document.getElementById('cc-pay').value)     || 0;

  const out = document.getElementById('calc-out');

  // Need at least an amount charged and an APR to show anything useful.
  if (!charged || !apr) {
    out.style.display = 'none';
    return;
  }
  out.style.display = 'block';

  // ---- Available credit & utilization ----
  if (limit > 0) {
    const available = Math.max(0, limit - charged);
    document.getElementById('r-available').textContent = fmt(available);

    const utilPct = Math.min(100, (charged / limit) * 100);
    const utilEl = document.getElementById('r-util');
    utilEl.textContent = utilPct.toFixed(1) + '%';
    // Color-code utilization the same way the Cards screen does
    utilEl.className = 'r-val ' + (utilPct > 70 ? 'danger' : utilPct > 30 ? '' : 'good');
  } else {
    document.getElementById('r-available').textContent = '—';
    document.getElementById('r-util').textContent = '—';
    document.getElementById('r-util').className = 'r-val';
  }

  // ---- Daily interest ----
  // Standard simple approximation: APR / 365 gives the daily rate,
  // multiplied by the current balance.
  const dailyInterest = charged * (apr / 100 / 365);
  document.getElementById('r-daily').textContent = fmt(dailyInterest) + '/day';

  // ---- Interest accrued by the due date ----
  if (dueStr) {
    const due = new Date(dueStr + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const daysUntilDue = Math.max(0, Math.ceil((due - today) / (1000 * 60 * 60 * 24)));
    document.getElementById('r-due').textContent = fmt(dailyInterest * daysUntilDue) +
      ` (${daysUntilDue} day${daysUntilDue === 1 ? '' : 's'})`;
  } else {
    document.getElementById('r-due').textContent = '—';
  }

  // ---- Optional payoff projection (only if a monthly payment was entered) ----
  const payoffSection = document.getElementById('calc-payoff-section');
  if (pay > 0) {
    payoffSection.style.display = 'block';
    const mr = apr / 100 / 12; // monthly interest rate

    if (pay <= charged * mr) {
      // The payment doesn't even cover one month's interest — balance never shrinks.
      document.getElementById('r-months').textContent = '∞';
      document.getElementById('r-interest').textContent = '∞';
      document.getElementById('r-tip').textContent =
        '⚠ This payment is less than the interest charged each month, so the balance would never go down. Increase the payment to make progress.';
      document.getElementById('calc-chart').innerHTML = '';
    } else {
      // Standard loan-payoff formula: how many months to reach $0
      // given a fixed monthly payment and monthly interest rate.
      const months = Math.ceil(-Math.log(1 - (charged * mr) / pay) / Math.log(1 + mr));

      // Simulate month-by-month to also total up the interest actually paid.
      let totalInterest = 0, remaining = charged;
      for (let i = 0; i < months; i++) {
        totalInterest += remaining * mr;
        remaining = remaining * (1 + mr) - pay;
      }

      document.getElementById('r-months').textContent = months + ' month' + (months === 1 ? '' : 's');
      document.getElementById('r-interest').textContent = fmt(totalInterest);
      document.getElementById('r-tip').textContent =
        `Paying ${fmt(pay)}/month, you'd be debt-free in ${months} month${months === 1 ? '' : 's'} and pay ${fmt(totalInterest)} in total interest.`;

      // Build a small milestone progress chart (25% / 50% / 75% / 100% of the way there)
      let chartHtml = '<div style="margin-top:16px;padding-top:16px;border-top:1px solid var(--border)"><div style="font-size:12px;color:var(--text3);margin-bottom:8px">Payoff milestones</div>';
      const milestones = [Math.floor(months * 0.25), Math.floor(months * 0.5), Math.floor(months * 0.75), months]
        .filter((m, i, arr) => m > 0 || i === arr.length - 1); // drop duplicate/zero early milestones for short payoffs

      let rem = charged;
      let prevMonth = 0;
      milestones.forEach(m => {
        for (let mo = prevMonth; mo < m; mo++) rem = rem * (1 + mr) - pay;
        const pctRemaining = Math.max(0, rem / charged * 100);
        chartHtml += `<div style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text2);margin-bottom:3px"><span>Month ${m}</span><span>${fmt(Math.max(0, rem))} remaining</span></div><div class="prog-bar"><div class="prog-fill orange" style="width:${(100 - pctRemaining).toFixed(0)}%"></div></div></div>`;
        prevMonth = m;
      });
      chartHtml += '</div>';
      document.getElementById('calc-chart').innerHTML = chartHtml;
    }
  } else {
    // No payment entered — hide the payoff section entirely
    payoffSection.style.display = 'none';
    document.getElementById('calc-chart').innerHTML = '';
    document.getElementById('r-tip').textContent =
      'Tip: enter a planned monthly payment above to see how long this would take to pay off.';
  }
}
